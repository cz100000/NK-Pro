# NK-Pro V93 als PWA auf GitHub Pages

## Inhalt

- `index.html` – bestehendes NK-Pro V93 mit PWA-Verknüpfung
- `manifest.webmanifest` – App-Name, Darstellung und Symbole
- `service-worker.js` – Offline-Cache
- `icons/` – App-Symbole für iPhone und andere Geräte
- `.nojekyll` – verhindert eine unnötige Jekyll-Verarbeitung

Die Berechnungslogik der V93 wurde nicht verändert.

## Veröffentlichung auf GitHub Pages

1. Bei GitHub ein neues Repository anlegen, zum Beispiel `nk-pro`.
2. Das Repository darf keine echten Abrechnungsdaten oder JSON-Sicherungen enthalten.
3. Den gesamten Inhalt dieses Ordners in die oberste Ebene des Repositorys hochladen.
4. Repository öffnen: **Settings → Pages**.
5. Unter **Build and deployment** als Quelle **Deploy from a branch** auswählen.
6. Branch **main** und Ordner **/(root)** auswählen und speichern.
7. Nach der Veröffentlichung auf **Visit site** klicken.

Die Adresse lautet normalerweise:

`https://DEIN-BENUTZERNAME.github.io/nk-pro/`

## Installation auf dem iPhone

1. Die veröffentlichte Adresse in Safari öffnen.
2. Teilen-Symbol antippen.
3. **Zum Home-Bildschirm** wählen.
4. Namen bestätigen und **Hinzufügen** antippen.
5. NK-Pro anschließend über das neue Symbol starten.
6. Nach dem ersten vollständigen Laden kann die App offline geöffnet werden.

## Datenschutz

GitHub Pages veröffentlicht die Programmdateien öffentlich. Die App enthält im Ausgangszustand keine Abrechnungsdaten. Nutzerdaten werden erst im Browser-LocalStorage des jeweiligen Geräts gespeichert.

Keine JSON-Backups, Abrechnungsdateien oder personenbezogenen Daten in das GitHub-Repository hochladen.

## Aktualisierung

Bei einer späteren Version die Webdateien im Repository ersetzen. Für einen geänderten Offline-Cache sollte in `service-worker.js` zusätzlich `CACHE_NAME` erhöht werden.
